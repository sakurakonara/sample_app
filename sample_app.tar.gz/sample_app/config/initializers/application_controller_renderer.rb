# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'aef3c37a302fcb60a70f87048588cb23e70b0e9011ed481a513200362bf1d2b327a88b5658c0ae1f343519437f0c8ef53b788528a07c55b5a6a9317adb1bc377'